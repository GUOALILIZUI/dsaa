<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;

class IndexController extends Controller
{
    //首页视图
    public function Index(){
        $sql="select * from goods where goods_hot=2 ";
        $arr=DB::select($sql);

        $where=[
            'is_tell'=>1
        ];
        $sql2='select * from goods where is_tell=1 limit 2';
//        $data=DB::table('goods')->where($where)->select();
        $data=DB::select($sql2);


        return view('index.index',['arr'=>$arr,'data'=>$data]);
    }

    //注册视图
    public function Register(){
        return view('index.register');
    }

    //登录视图
    public function login(){
        return view('index.login');
    }

    //注册
    public function add(Request $request){
        $arr=$request->input();
        $l_tel=$arr['l_tel'];
        $l_pwd=$arr['l_pwd'];
        $conpwd=$arr['conpwd'];
        $code=$arr['code'];
//        echo $code;exit;

            if($l_pwd !==$conpwd){
                $nul=array(
                    'status'=>0,
                    'msg'=>'密码与确认密码保持一致',
                );
                return $nul;exit;
            }
            $time=time();
            $codeWhere=[
                'tel'=>$l_tel,
                'code'=>$code,
                'status'=>1
            ];
            $code=DB::table('codes')->where($codeWhere)->first();

            if($code){
                if($time>$code->timeout){
                    $nul=[
                        'status'=>0,
                        'msg'=>'验证码已失效'
                    ];
                    return $nul;
                }
            }else{
                $nul=[
                    'status'=>0,
                    'msg'=>'验证码错误'
                ];
                return $nul;
            }

            $res=DB::table('login')->where('l_tel',$l_tel)->first();
            if(!empty($res)){
                $nul=array(
                    'status'=>0,
                    'msg'=>'手机号已存在',
                );
                return $nul;
            }
            $pwd=md5($l_pwd);
            $arrInfo=array(
                'l_tel'=>$l_tel,
                'l_pwd'=>$pwd
            );

            $register=DB::table('login')->insert($arrInfo);
            if($register){
                $nul=array(
                    'status'=>1,
                    'msg'=>'注册成功',
                );
                return $nul;
            }



    }

    //登录
    public function log(Request $request){
        $arr=$request->input();
        $l_tel=$arr['l_tel'];
        $l_pwd=$arr['l_pwd'];
        $pwd=md5($l_pwd);
        $where=['l_tel'=>$l_tel,'l_pwd'=>$pwd];
        $arrInfo=DB::table('login')->where($where)->first();

//        var_dump($arrInfo);exit;

        if($arrInfo){
            $id=$arrInfo->l_id;
            $l_tel=$arrInfo->l_tel;
            session(['l_id'=>$id,'l_tel'=>$l_tel]);
            return array('status'=>1,'msg'=>'登陆成功');
        }else{
            return array('status'=>0,'msg'=>'登录失败');

        }
    }

    //验证码
    public function t1(Request $request){
        $tel=$request->input('tel');
        //创建验证码
        $num=rand(1000,9999);
//        $obj= new \send();
//        $bol=$obj->show($tel,$num);
        $bol=100;
        if($bol==100){
            $arr=array(
                'tel'=>$tel,
                'code'=>$num,
                'timeout'=>time()+60,
                'status'=>1
            );
            $res=DB::table('codes')->insert($arr);
            var_dump($res);

        }





    }

    //猜你喜欢
    public function adddo(Request $request){
        //空数组
        $arr=array();
        //拿到当前页码  默认为第一页
        $page=$request->input('page',1);
        //每页显示条数
        $pageNum=2;
        //求出第几页  偏移量
        $offset=($page-1) * $pageNum;
        //查询表里数据
        $dataInfo=DB::table('goods')->offset($offset)->limit($pageNum)->get();
        //查询总条数
        $count=DB::table('goods')->count();
        //总条数/每页显示条数
        $pageCount=ceil($count/$pageNum);
        //显示视图
        $objView=view('index.like',['arr'=>$dataInfo]);
        //response获取页面原始代码
        $content=response($objView)->getContent();
        $arr['info']=$content;
        $arr['page']=$pageCount;

        return $arr;





    }
}
