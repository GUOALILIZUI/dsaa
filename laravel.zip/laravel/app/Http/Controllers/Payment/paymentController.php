<?php

namespace App\Http\Controllers\Payment;


use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use Illuminate\Support\Facades\DB;
use App\Models\Goods;
use App\Models\Cart;
use App\Models\Payment;



class PaymentController extends Controller
{
    //订单表显示视图
    public function payAll(Request $request){
        $order_id=$request->input('order_id');
        $order_id=explode(',',$order_id);
        $where=[
            'goods_status'=>1
        ];
        $arr=DB::table('order_detail')
            ->join('order','order.order_id','=','order_detail.order_id')
            ->where($where)
            ->whereIn('order_detail.order_id',$order_id)
            ->get();
//        print_r($arr);exit;
        return view('payment.payall',['arr'=>$arr]);
    }




}
