<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Title</title>
</head>
<body>
<form action="/form2" method="post">
    <input type="text" name="name" value="">
    <input type="submit" value="submit">
</form>
</body>
</html>
<script src="/js/jquery-3.1.1.min.js"></script>