<!--底部-->
<div class="footer clearfix">
    <ul>
        <li class="f_home"><a href="/v41/index.do" class="hover"><i></i>潮购</a></li>
        <li class="f_announced"><a href="all/" ><i></i>所有商品</a></li>
        <li class="f_single"><a href="/v41/post/index.do" ><i></i>最新揭晓</a></li>
        <li class="f_car"><a id="btnCart" href="/v41/mycart/index.do" ><i></i>购物车</a></li>
        <li class="f_personal"><a href="/Cord" ><i></i>我的潮购</a></li>
    </ul>
</div>