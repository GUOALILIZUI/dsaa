<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Title</title>
</head>
<body>

<form action="upd" method="post" onsubmit="return false" id="sll">
    <input type="hidden" name="id" value="<?php echo e($arr->id); ?>" id="l">
    <table border="2">
        <tr>
            <td>&nbsp;&nbsp;名称</td>
            <td><input type="text" name="name" value="<?php echo e($arr->name); ?>"></td>
        </tr>
        <tr>
            <td>&nbsp;&nbsp;分类</td>
            <td>
                <select name="c_id" id="" value="<?php echo e($arr->c_id); ?>">
                    <?php $__currentLoopData = $cate; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $v): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <?php if($v->c_id==$arr->c_id): ?>
                            <option value="<?php echo e($v->c_id); ?>" selected><?php echo e($v->cate_name); ?></option>
                        <?php else: ?>
                            <option value="<?php echo e($v->c_id); ?>" ><?php echo e($v->cate_name); ?></option>
                        <?php endif; ?>
                     <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>
            </td>
        </tr>
        <tr>
            <td>&nbsp;&nbsp;描述</td>
            <td>
                <textarea name="desc" id="" cols="30" rows="10">
<?php echo e($arr->desc); ?>

                </textarea>
            </td>
        </tr>
        <tr>
            <td>是否热卖</td>
            <td>

                <input type="radio" name="is_hot" value="1" <?php if($arr->is_hot==1): ?> checked <?php endif; ?>>是
                <input type="radio" name="is_hot" value="2" <?php if($arr->is_hot==2): ?> checked <?php endif; ?>>否

            </td>
        </tr>
        <tr>
            <td>是否上架</td>
            <td>
                <input type="radio" name="is_sell"  value="1" <?php if($arr->is_sell==1): ?> checked <?php endif; ?>>是
                <input type="radio" name="is_sell" value="2" <?php if($arr->is_sell==2): ?> checked <?php endif; ?>>否
            </td>
        </tr>
<tr>
    <td><input type="button" value="submit" class="btn"></td>
</tr>
</table>
</form>
</body>
</html>
<script src="/js/jquery-3.2.1.min.js"></script>
<script>
$(function(){
    $('.btn').click(function(){
        var data=$('#sll').serialize();

        $.ajax({
            url: "upd",
            method: "POST",
            data:data,
            success:function(res){
                if(res==1){
                    alert('修改成功');
                    location.href='list';
                }else{
                    alert('修改失败');
                    location.href='list';
                }
            }
        })


    })
})

</script>